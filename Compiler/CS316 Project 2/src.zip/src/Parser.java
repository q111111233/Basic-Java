/**

This class is a top-down, recursive-descent parser for the following syntactic categories:

<assignment list> --> <assignment> | <assignment> <assignment list>
<assignment> --> <id> = <E> ";"
<E> --> <term> | <term> + <E> | <term> - <E>
<term> --> <primary> | <primary> * <term> | <primary> / <term>
<primary> --> <id> | <int> | <float> | <floatE> | "(" <E> ")" 

The definitions of the tokens are given in the lexical analyzer class file "lexArithArray.java".

The following variables and functions of the "lexArithArray" class are used:

static String t // holds an extracted token
static State state // the current state of the finite automaton
static int getToken() // extracts the next token
static void display(String s)
static void displayln(String s)
static void setIO(String inFile, String outFile)
static void closeIO()

An explicit parse tree is constructed in the form of nested class objects.

The main function will display the parse tree in linearly indented form.
Each syntactic category name labeling a node is displayed on a separate line, 
prefixed with the integer i representing the node's depth and indented by i blanks. 

 **/


public abstract class Parser extends LexAnalyzer
{
	static boolean errorFound = false;

	public static AbFunDefList funDefList()
	{
		FunDef_ fd = funDef();

		if (state == State.LParen)
		{
			AbFunDefList fdl = funDefList();
			return new MultiFunDefList(fd, fdl);
		}
		else
			return fd;
	}

	public static FunDef_ funDef()
	{
		if (state == State.LParen)
		{
			getToken();
			if (state == State.Keyword_define)
			{
				getToken();
				Header h = header();
				Exp e = exp();

				if (state == State.RParen)
				{
					getToken();
				}
				else
				{
					errorMsg(1);
					return null;
				}
				return new FunDef_(h, e);
			}
		}
		else
			errorMsg(0);

		return null;
	}
	public static Header header() 
	{
		if (state == State.LParen)
		{
			getToken();
			FunName fn = funName();
			if (state == State.RParen)
			{
				getToken();
				return new Header(fn, new EmptyParameter());
			}
			if (state == State.Id)
			{
				AbParameterList pl = Parameter();

				if (state == State.RParen)
				{
					getToken();
					return new Header(fn,pl);
				}
				else
				{
					errorMsg(5);
				}
			}
		}
		else
			errorMsg(1);	
		return null;
	}

	public static AbParameterList Parameter() 
	{
		ParameterListID pl = ParameterList();

		if (state == State.Id)
		{
			AbParameterList mpl = Parameter();
			return new MultiParameterList (pl, mpl);
		}
		else
			return pl;
	}

	public static ParameterListID ParameterList()
	{
		ParameterListID pid = new ParameterListID(t);
		getToken();
		return pid;
	}

	public static FunName funName() {
		if (state == State.Id)
		{
			FunName fn = new FunName(t);
			getToken();
			return fn;
		}
		else
		{
			errorMsg(5);
			return null;
		}
	}

	public static Exp exp ()
	{
		{

			switch ( state )
			{
			case Id:
				ExpId id = new ExpId(t);
				getToken();
				return id;

			case Int:
				ExpInt intElem = new ExpInt(Integer.parseInt(t));
				getToken();
				return intElem;

			case Float: 
			case FloatE:
				ExpFloat floatElem = new ExpFloat(t);
				getToken();
				return floatElem;

			case LParen:
				getToken();

				ListExpInside ele = ListExp_Exp();

				if ( state == State.RParen )
					getToken();
				else
				{
					errorMsg(1);
					return null;
				}
				return ele;
			case Keyword_false:
			case Keyword_true:
				ExpBool boolElem = new ExpBool(t);
				getToken();
				return boolElem;
			default:
				errorMsg(2);
				return null;
			}
		}
	}

	public static ListExpInside ListExp_Exp() 
	{
		switch (state)
		{
		case Keyword_if:
			getToken();
			return LEIIf();
		case Keyword_cond:

			getToken();
			return new LEICond (LEICord());
		}
		return null;
	}


	public static AbCaseList LEICord() 
	{
		CaseExp cl = caseList();
		if (state == State.LParen)
		{
			AbCaseList acl = caseList();
			return new MultiCaseList(cl, acl);
		}
		else
			return cl;

	}

	public static CaseExp caseList()
	{
		if (state == State.LParen)
		{
			getToken();
			Exp e1 = exp();
			Exp e2 = null;
			if (state != State.Keyword_else)
				e2 = exp();
			else if (state == State.Keyword_else)
				getToken();
			
			
			if (state==State.RParen)
				getToken();
			else
				errorMsg(5);
			return new CaseExp (e1, e2);
		}
		else
			errorMsg(6);
		return null;
	}

	public static LEIIf LEIIf()
	{
		Exp e1 = exp();
		Exp e2 = exp();
		Exp e3 = exp();
		return new LEIIf (e1, e2, e3);
	}
	public static void errorMsg(int i)
	{
		errorFound = true;
		display(t + ": unexpected symbol where");
		switch( i )
		{
		case 0: displayln(" ( expected ");
		case 1:	displayln(" arith op or ) expected"); return;
		case 2: displayln(" id, int, float, or ( expected"); return;
		case 3:	displayln(" = expected"); return;
		case 4:	displayln(" ; expected"); return;
		case 5:	displayln(" id expected"); return;	
		case 6: displayln(" ( expected");
		}
	}


	public static void main(String argv[])
	{
		// argv[0]: input file containing the source code of an assignment list
		// argv[1]: output file to display the parse tree
		setLex( argv[0], argv[1] );
		getToken();
		AbFunDefList fd = funDefList();

		if ( ! t.isEmpty() )
			displayln(t + "  -- unexpected symbol");
		else if ( ! errorFound )
		{
			fd.printParseTree(""); // print the parse tree in linearly indented form in argv[1] file
		}
		closeIO();
	}
}
