
public class EmptyParameter extends AbParameterList
{
	String id = "";
	
	public EmptyParameter ()
	{	
	}
	
	void printParseTree(String indent) 
	{
		return;
	}

	
}
