
public class FunCall extends ListExpInside
{
	FunName fn ;
	ExpList el;
	public FunCall (FunName fn , ExpList el)
	{
		this.fn = fn;
		this.el = el;
	}
	
	public void printParseTree (String indent)
	{
		super.printParseTree(indent);
		
	}
}
