
public abstract class AbFunDefList 
{

	abstract void printParseTree(String indent);
}
