

public class FunDef_ extends AbFunDefList
{
	Header h;
	Exp e;
	
	//Need exp here Implement later.
	public FunDef_ (Header h, Exp e)
	{
		this.h = h;
		this.e = e;
	}

	
	
	public void printParseTree(String indent)
	{			

		Parser.displayln(indent + indent.length() + " <fun def>" + FunDef_.class.getSimpleName());
		h.printParseTree(indent+" ");
		e.printParseTree(indent+" ");
	}
}
