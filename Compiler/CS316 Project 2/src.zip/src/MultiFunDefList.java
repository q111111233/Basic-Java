
public class MultiFunDefList extends AbFunDefList{
	FunDef_ fd;
	AbFunDefList fdl;

	public MultiFunDefList(FunDef_ fd, AbFunDefList fdl)
	{
		this.fd = fd;
		this.fdl = fdl;
	}
	
	public void printParseTree(String indent)
	{
		fd.printParseTree(indent);
		fdl.printParseTree(indent);
	}
}
