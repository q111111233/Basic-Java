
public class ExpId extends Exp
{
	String id;
	
	public ExpId(String id)
	{
		this.id = id;
	}
	
	void printParseTree(String indent) 
	{
		super.printParseTreeHeader(indent);
		Parser.displayln((indent+=" ") + indent.length() + " " + id);
	}
}
