
public class EmptyParameterList extends AbParameterList
{
	String id = "";
	
	
	void printParseTree(String indent) 
	{
		System.out.println("Good");
		return;
	}

	
}
