
public class ExpListEmpty extends AbExpList
{

	@Override
	public void printParseTree(String indent) 
	{
	}

}
