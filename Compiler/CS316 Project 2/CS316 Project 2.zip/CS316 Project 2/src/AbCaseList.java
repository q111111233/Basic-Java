
public abstract class AbCaseList
{
	abstract void printParseTree(String indent);
}
